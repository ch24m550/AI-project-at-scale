import json, mlflow, mlflow.spark
from pyspark.sql import SparkSession
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from src.utils.io import write_json

spark = SparkSession.builder.appName("titanic-eval").getOrCreate()
model_uri = open("data/processed/best_model_path.txt").read().strip()
model = mlflow.spark.load_model(model_uri)

df = spark.read.parquet("data/processed/train_features.parquet").join(
    spark.read.parquet("data/processed/train_labels.parquet")
)

preds = model.transform(df)
auc = BinaryClassificationEvaluator(labelCol="label", metricName="areaUnderROC").evaluate(preds)
acc = preds.selectExpr('int(label=prediction) as correct').groupBy().avg('correct').first()[0]

write_json("data/processed/metrics.json", {"auc": float(auc), "accuracy": float(acc)})

# Confusion matrix plot
import pandas as pd
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt

pdf = preds.select('label','prediction').toPandas()
cm = confusion_matrix(pdf['label'], pdf['prediction'])
plt.figure()
plt.imshow(cm)
plt.title('Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('True')
for i in range(cm.shape[0]):
    for j in range(cm.shape[1]):
        plt.text(j, i, str(cm[i,j]), ha='center', va='center')
plt.savefig('data/processed/confusion_matrix.png', bbox_inches='tight')
plt.close()

spark.stop()