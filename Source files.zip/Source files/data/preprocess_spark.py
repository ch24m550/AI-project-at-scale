import argparse, yaml, sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from pyspark.ml.feature import StringIndexer, OneHotEncoder, VectorAssembler
from pyspark.ml import Pipeline
from pathlib import Path

# Robust import of schema
try:
    from src.data.schema import schema
except Exception:
    sys.path.append(str(Path(__file__).resolve().parent))
    from schema import schema

parser = argparse.ArgumentParser()
parser.add_argument("--params", required=True)
args = parser.parse_args()

params = yaml.safe_load(open(args.params))
pp = params["preprocess"]

spark = (SparkSession.builder
         .appName("titanic-preprocess")
         .getOrCreate())

raw = spark.read.csv("data/raw/train.csv", header=True, schema=schema)

# Drop unused columns
df = raw.drop(*pp.get("drop_cols", []))

# Basic imputations
df = df.fillna({"Embarked": "S"})
# Age & Fare median impute using approx quantile
age_median = df.approxQuantile("Age", [0.5], 0.001)[0]
fare_median = df.approxQuantile("Fare", [0.5], 0.001)[0]
df = df.fillna({"Age": age_median, "Fare": fare_median})

categorical = ["Sex", "Embarked"]
indexers = [StringIndexer(inputCol=c, outputCol=f"{c}_idx", handleInvalid="keep")
            for c in categorical]
enc = OneHotEncoder(inputCols=[f"{c}_idx" for c in categorical],
                    outputCols=[f"{c}_oh" for c in categorical])

features = ["Pclass", "Age", "SibSp", "Parch", "Fare"] + [f"{c}_oh" for c in categorical]
assembler = VectorAssembler(inputCols=features, outputCol="features")

pipe = Pipeline(stages=indexers + [enc, assembler])
model = pipe.fit(df)
X = model.transform(df).select("features", col(pp["target_col"]).alias("label"))

out = Path(pp["output_dir"]).resolve()
out.mkdir(parents=True, exist_ok=True)
X.select("features").write.mode("overwrite").parquet(str(out / "train_features.parquet"))
X.select("label").write.mode("overwrite").parquet(str(out / "train_labels.parquet"))

spark.stop()