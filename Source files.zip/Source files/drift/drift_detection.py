import argparse, os
import pandas as pd
from scipy.stats import ks_2samp
import subprocess

ap = argparse.ArgumentParser()
ap.add_argument('--new_data', required=True)
ap.add_argument('--ref', required=True)
ap.add_argument('--threshold', type=float, default=0.2)
ap.add_argument('--on-drift', default='')
args = ap.parse_args()

new_df = pd.read_csv(args.new_data)
keep = ["Pclass","Age","SibSp","Parch","Fare"]
new_df = new_df[keep].dropna()

try:
    import pyarrow.parquet as pq
    ref = pq.read_table(args.ref).to_pandas()
    # This is a vector column in Spark output; users should keep a numeric snapshot for reliable drift.
    # Fallback to a CSV snapshot if available.
    raise Exception("Use numeric snapshots for reliable drift; see README")
except Exception:
    ref_path = 'data/processed/train_numeric.csv'
    if os.path.exists(ref_path):
        ref = pd.read_csv(ref_path)
    else:
        ref = new_df.sample(min(100, len(new_df)))

stats = {}
drift_flags = []
for col in keep:
    d = ks_2samp(new_df[col], ref[col])
    stats[col] = {"ks_stat": float(d.statistic), "pvalue": float(d.pvalue)}
    drift_flags.append(d.statistic > args.threshold)

print("Drift Stats:", stats)

if any(drift_flags) and args.on_drift:
    subprocess.run(args.on_drift, shell=True, check=False)