from fastapi import FastAPI
from pydantic import BaseModel
import mlflow

app = FastAPI(title="Titanic Predictor")

class Passenger(BaseModel):
    Pclass: int
    Sex: str
    Age: float
    SibSp: int
    Parch: int
    Fare: float
    Embarked: str

class Batch(BaseModel):
    records: list[Passenger]

@app.on_event("startup")
def load_model():
    global model
    model = mlflow.pyfunc.load_model("models:/titanic_spark/Production")

@app.post("/predict")
def predict(batch: Batch):
    import pandas as pd
    df = pd.DataFrame([r.dict() for r in batch.records])
    preds = model.predict(df)
    return {"predictions": preds.tolist()}