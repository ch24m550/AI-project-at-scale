import argparse, yaml
from pyspark.sql import SparkSession
from pyspark.ml.classification import LogisticRegression, RandomForestClassifier, DecisionTreeClassifier
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder
from pyspark.ml.evaluation import BinaryClassificationEvaluator
import mlflow, mlflow.spark
from src.utils.mlflow_utils import start_run
from src.utils.io import write_text

parser = argparse.ArgumentParser()
parser.add_argument("--params", required=True)
args = parser.parse_args()
params = yaml.safe_load(open(args.params))
trainp = params["train"]

spark = SparkSession.builder.appName("titanic-train").getOrCreate()
X = spark.read.parquet("data/processed/train_features.parquet")
y = spark.read.parquet("data/processed/train_labels.parquet")
df = X.join(y)

if trainp["model_type"] == "random_forest":
    clf = RandomForestClassifier(featuresCol="features", labelCol="label", numTrees=trainp["rf_trees"])
if trainp["model_type"] == "Decision_Tree":
    clf = DecisionTreeClassifier(featuresCol="features", labelCol="label",  maxDepth=trainp["max_dep"])
else:
    clf = LogisticRegression(featuresCol="features", labelCol="label", maxIter=trainp["max_iter"])

paramGridBuilder = ParamGridBuilder()
if hasattr(clf, 'regParam'):
    paramGridBuilder = paramGridBuilder.addGrid(clf.regParam, [0.0, 0.01, 0.1])
paramGrid = paramGridBuilder.build()

auc_eval = BinaryClassificationEvaluator(labelCol="label", metricName="areaUnderROC")

with start_run("titanic_spark_experiments"):
    if len(paramGrid) > 0:
        cv = CrossValidator(estimator=clf, estimatorParamMaps=paramGrid, evaluator=auc_eval, numFolds=params["train"]["crossval_folds"])
        model = cv.fit(df)
        best = model.bestModel
    else:
        best = clf.fit(df)

    preds = best.transform(df)
    auc = auc_eval.evaluate(preds)
    acc = preds.selectExpr('int(label=prediction) as correct').groupBy().avg('correct').first()[0]

    mlflow.log_param("model_type", trainp["model_type"])
    mlflow.log_metric("auc", float(auc))
    mlflow.log_metric("accuracy", float(acc))

    mlflow.spark.log_model(best, artifact_path="model")
    info = mlflow.active_run().info
    model_uri = f"runs:/{info.run_id}/model"
    write_text("data/processed/best_model_path.txt", model_uri)

spark.stop()