import argparse, yaml, mlflow
from src.utils.mlflow_utils import register_model

parser = argparse.ArgumentParser()
parser.add_argument("--params", required=True)
args = parser.parse_args()
params = yaml.safe_load(open(args.params))

model_uri = open("data/processed/best_model_path.txt").read().strip()
name = params["register"]["model_name"]
reg = register_model(model_uri, name)
print(f"Registered: {reg.name} v{reg.version}")