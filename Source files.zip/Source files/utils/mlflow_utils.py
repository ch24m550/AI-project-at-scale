import os
import mlflow

_DEF_URI = os.getenv("MLFLOW_TRACKING_URI", "file:///mnt/c/Users/rnisa/Downloads/mlops-titanic-java8-compatible/mlruns")

def start_run(exp_name: str):
    mlflow.set_tracking_uri(_DEF_URI)
    mlflow.set_experiment(exp_name)
    return mlflow.start_run()

def register_model(model_uri: str, name: str):
    mlflow.set_tracking_uri(_DEF_URI)
    return mlflow.register_model(model_uri=model_uri, name=name)