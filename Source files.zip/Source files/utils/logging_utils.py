from loguru import logger

def get_logger(name: str = "mlops"):
    logger.remove()
    logger.add(lambda msg: print(msg, end=""))
    return logger.bind(module=name)